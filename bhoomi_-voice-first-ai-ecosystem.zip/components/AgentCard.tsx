import React from 'react';

interface AgentCardProps {
  number: string;
  name: string;
  role: string;
  description: string;
  colorClass: string;
}

export const AgentCard: React.FC<AgentCardProps> = ({ number, name, role, description, colorClass }) => {
  return (
    <div className="bg-[#16213e] rounded-xl overflow-hidden shadow-lg border border-white/5 transform hover:scale-[1.02] transition-all duration-300 group">
      <div className={`h-2 w-full ${colorClass}`}></div>
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
             <span className={`text-4xl font-extrabold ${colorClass.replace('bg-', 'text-')} opacity-80`}>
                {number}
             </span>
             <h3 className="text-xl font-bold text-white mt-1">{name}</h3>
          </div>
          <div className={`p-2 rounded-full bg-white/5 group-hover:bg-white/10 transition-colors`}>
             {/* Icon Placeholder */}
             <svg className="w-6 h-6 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
        </div>
        <p className="text-[#e94560] font-medium text-sm mb-3 uppercase tracking-wide">{role}</p>
        <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  );
};