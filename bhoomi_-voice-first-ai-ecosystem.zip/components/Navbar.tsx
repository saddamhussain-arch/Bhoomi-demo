import React from 'react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'ecosystem', label: 'Ecosystem' },
    { id: 'assistant', label: 'Try Agent 0' },
    { id: 'impact', label: 'Impact' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#16213e] shadow-lg border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex-shrink-0 flex items-center cursor-pointer" onClick={() => setActiveTab('home')}>
            <span className="text-3xl font-extrabold text-[#e94560] tracking-wider">BHOOMI</span>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                    activeTab === item.id
                      ? 'bg-[#e94560] text-white shadow-lg shadow-red-500/20'
                      : 'text-gray-300 hover:bg-[#e94560]/20 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Mobile simplified nav */}
      <div className="md:hidden flex justify-around bg-[#1a1a2e] py-2 border-t border-white/5">
         {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`text-xs px-2 py-1 ${activeTab === item.id ? 'text-[#e94560] font-bold' : 'text-gray-400'}`}
            >
              {item.label}
            </button>
         ))}
      </div>
    </nav>
  );
};