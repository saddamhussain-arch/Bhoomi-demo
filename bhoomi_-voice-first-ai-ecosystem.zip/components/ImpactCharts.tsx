import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { EconomicMetric } from '../types';

const data: EconomicMetric[] = [
  { year: '2024', povertyRate: 15.0, literacyRate: 74, gdpGrowth: 6.5 },
  { year: '2025', povertyRate: 12.5, literacyRate: 78, gdpGrowth: 7.2 },
  { year: '2026', povertyRate: 8.0, literacyRate: 85, gdpGrowth: 8.4 },
  { year: '2027', povertyRate: 4.5, literacyRate: 92, gdpGrowth: 9.8 },
  { year: '2028', povertyRate: 1.5, literacyRate: 98, gdpGrowth: 11.5 },
  { year: '2029', povertyRate: 0.1, literacyRate: 100, gdpGrowth: 13.0 }, // Target Reached
];

export const ImpactCharts: React.FC = () => {
  return (
    <div className="space-y-12 py-8">
      
      {/* Target Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#16213e] p-6 rounded-xl border border-green-500/20 shadow-lg">
          <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Poverty Target</h3>
          <div className="text-4xl font-extrabold text-white">0.1%</div>
          <div className="text-green-400 text-sm mt-1">From 15% (2024 Baseline)</div>
        </div>
        <div className="bg-[#16213e] p-6 rounded-xl border border-blue-500/20 shadow-lg">
          <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Education Target</h3>
          <div className="text-4xl font-extrabold text-white">100%</div>
          <div className="text-blue-400 text-sm mt-1">Full Functional Literacy</div>
        </div>
        <div className="bg-[#16213e] p-6 rounded-xl border border-[#e94560]/20 shadow-lg">
          <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-2">Growth Impact</h3>
          <div className="text-4xl font-extrabold text-white">+50%</div>
          <div className="text-[#e94560] text-sm mt-1">Projected GDP Multiplier</div>
        </div>
      </div>

      {/* Chart 1: Poverty Eradication Curve */}
      <div className="bg-[#16213e] p-6 rounded-xl border border-white/5 shadow-2xl">
        <h3 className="text-2xl font-bold mb-6 text-white">The Path to 0.1% Poverty</h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorPoverty" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#e94560" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#e94560" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="year" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1a1a2e', borderColor: '#e94560', color: '#fff' }} 
              />
              <Area 
                type="monotone" 
                dataKey="povertyRate" 
                stroke="#e94560" 
                fillOpacity={1} 
                fill="url(#colorPoverty)" 
                name="Poverty Rate (%)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Education vs Growth */}
      <div className="bg-[#16213e] p-6 rounded-xl border border-white/5 shadow-2xl">
        <h3 className="text-2xl font-bold mb-6 text-white">Literacy & Economic Growth Correlation</h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
              <XAxis dataKey="year" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                 contentStyle={{ backgroundColor: '#1a1a2e', borderColor: '#4f46e5', color: '#fff' }}
                 cursor={{fill: '#1f2937'}}
              />
              <Legend />
              <Bar dataKey="literacyRate" name="Literacy (%)" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="gdpGrowth" name="GDP Growth (%)" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};