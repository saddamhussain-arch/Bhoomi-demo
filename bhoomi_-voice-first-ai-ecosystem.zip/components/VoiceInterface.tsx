import React, { useState, useRef, useEffect } from 'react';
import { generateResponse } from '../services/gemini';
import { speak, startListening, stopSpeaking } from '../services/speech';
import { AgentType, ChatMessage } from '../types';

export const VoiceInterface: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'listening' | 'processing' | 'speaking'>('idle');
  const statusRef = useRef(status);

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'system', text: 'Namaste. I am Bhoomi. Tap the microphone to speak.', timestamp: new Date() }
  ]);
  const [activeAgent, setActiveAgent] = useState<AgentType>(AgentType.GENERAL);
  const [micAvailable, setMicAvailable] = useState<boolean>(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleMicClick = () => {
    if (!micAvailable) {
      addMessage('system', "Microphone is unavailable. Please use the text box below.");
      textInputRef.current?.focus();
      return;
    }

    if (status === 'speaking') {
      stopSpeaking();
      setStatus('idle');
      return;
    }

    if (status === 'listening') {
      return; // Already listening
    }

    setStatus('listening');
    stopSpeaking(); // Ensure silence before listening

    startListening(
      (text) => {
        handleUserInput(text);
      },
      () => {
        // On End (Silence or Stop)
        if (statusRef.current === 'listening') {
           setStatus('idle'); 
        }
      },
      (errorMsg) => {
        console.error("Mic Error:", errorMsg);
        setStatus('idle');
        
        if (errorMsg.includes("No speech")) {
           // Ignore "no speech" errors to avoid spamming chat
        } else {
           addMessage('system', `⚠️ ${errorMsg}`);
           
           // If it's a hardware/permission issue, disable mic button
           if (errorMsg.includes("No microphone") || errorMsg.includes("access denied") || errorMsg.includes("not supported")) {
             setMicAvailable(false);
             setTimeout(() => {
                textInputRef.current?.focus();
             }, 500);
           }
        }
      }
    );
  };

  const handleUserInput = async (text: string) => {
    if (!text.trim()) return;

    setStatus('processing');
    addMessage('user', text);

    // Identify Intent loosely for visual Agent switching
    let context = activeAgent;
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('learn') || lowerText.includes('read') || lowerText.includes('write') || lowerText.includes('teach')) {
      context = AgentType.AGENT_6;
      setActiveAgent(AgentType.AGENT_6);
    } else if (lowerText.includes('listen') || lowerText.includes('note') || lowerText.includes('record')) {
      context = AgentType.AGENT_0;
      setActiveAgent(AgentType.AGENT_0);
    } else if (lowerText.includes('say') || lowerText.includes('speak') || lowerText.includes('translate')) {
        context = AgentType.AGENT_1;
        setActiveAgent(AgentType.AGENT_1);
    } else {
      context = AgentType.GENERAL;
      setActiveAgent(AgentType.GENERAL);
    }

    // Call Gemini
    const responseText = await generateResponse(text, context);
    
    addMessage('model', responseText);
    setStatus('speaking');
    
    // Agent 1 (Text-to-Voice) logic
    speak(responseText, () => {
      setStatus('idle');
    });
  };

  const addMessage = (role: 'user' | 'model' | 'system', text: string) => {
    setMessages(prev => [...prev, { role, text, timestamp: new Date() }]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-2xl mx-auto bg-[#1a1a2e] rounded-xl overflow-hidden shadow-2xl border border-white/5 relative">
      
      {/* Header / Active Agent Display */}
      <div className="p-4 bg-[#16213e] flex items-center justify-between border-b border-white/5">
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${status === 'listening' ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></div>
          <span className="font-bold text-[#e94560] transition-all duration-500">{activeAgent}</span>
        </div>
        <div className="text-xs text-gray-400 font-mono uppercase tracking-widest">
           {status === 'idle' && (micAvailable ? 'ONLINE' : 'TEXT ONLY')}
           {status === 'listening' && 'LISTENING...'}
           {status === 'processing' && 'AGENT THINKING...'}
           {status === 'speaking' && 'AGENT SPEAKING...'}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              msg.role === 'user' 
                ? 'bg-[#e94560] text-white rounded-br-none shadow-lg' 
                : msg.role === 'system'
                  ? 'bg-yellow-500/10 text-yellow-200 border border-yellow-500/30 text-sm'
                  : 'bg-[#16213e] text-gray-200 rounded-bl-none border border-white/5 shadow-md'
            }`}>
              <p className="text-lg leading-relaxed">{msg.text}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Interaction Area */}
      <div className="p-6 bg-[#16213e] flex flex-col items-center justify-center border-t border-white/5">
        
        {/* The Big Button - Designed for Accessibility */}
        <button 
          onClick={handleMicClick}
          disabled={!micAvailable && status !== 'speaking'}
          className={`relative group w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 focus:outline-none ${
            !micAvailable && status !== 'speaking'
              ? 'bg-gray-700 cursor-not-allowed opacity-50'
              : status === 'listening' 
                ? 'bg-red-500 shadow-[0_0_30px_rgba(239,68,68,0.6)] scale-110' 
                : 'bg-[#e94560] hover:bg-[#ff5e78] shadow-lg hover:shadow-red-500/30'
          }`}
          aria-label={!micAvailable ? "Microphone Unavailable" : status === 'listening' ? "Stop listening" : "Start listening"}
        >
          {status === 'listening' && (
             <span className="absolute w-full h-full rounded-full bg-red-500 opacity-75 animate-ping"></span>
          )}
          
          <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             {!micAvailable && status !== 'speaking' ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
             ) : status === 'speaking' ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            )}
          </svg>
        </button>

        <p className="mt-4 text-gray-400 text-sm font-medium">
          {!micAvailable 
             ? 'Microphone Unavailable - Use Text Below' 
             : status === 'idle' ? 'Tap to Speak' : status === 'listening' ? 'Listening...' : 'Processing...'}
        </p>
        
        {/* Fallback Text Input for browser compatibility or noise */}
        <form 
          onSubmit={(e) => {
            e.preventDefault();
            const input = (e.currentTarget.elements.namedItem('textInput') as HTMLInputElement);
            if(input.value.trim()) {
                handleUserInput(input.value);
                input.value = '';
            }
          }}
          className="w-full mt-6 flex border-t border-gray-700 pt-4"
        >
            <input 
                ref={textInputRef}
                name="textInput"
                type="text" 
                placeholder={!micAvailable ? "Type your message here..." : "Or type here..."} 
                className={`flex-1 bg-[#1a1a2e] text-white px-4 py-3 rounded-l-lg border ${!micAvailable ? 'border-[#e94560] ring-1 ring-[#e94560]' : 'border-gray-600'} focus:border-[#e94560] outline-none transition-colors`}
                autoComplete="off"
            />
            <button type="submit" className="bg-[#16213e] px-6 py-3 rounded-r-lg border border-l-0 border-gray-600 hover:bg-[#e94560] hover:border-[#e94560] hover:text-white font-semibold transition-all">
                Send
            </button>
        </form>
      </div>
    </div>
  );
};
