// Simple wrapper around browser Speech APIs

export const speak = (text: string, onEnd?: () => void) => {
  if (!('speechSynthesis' in window)) return;

  // Cancel any current speaking
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-IN'; // Indian English context
  utterance.rate = 0.9; // Slightly slower for clarity
  utterance.pitch = 1.0;

  utterance.onend = () => {
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
};

export const stopSpeaking = () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
};

// Type definition for Web Speech API
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

export const startListening = (
  onResult: (text: string) => void,
  onEnd: () => void,
  onError: (error: string) => void
) => {
  const windowObj = window as unknown as IWindow;
  const SpeechRecognition = windowObj.SpeechRecognition || windowObj.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    onError("Speech recognition not supported in this browser. Please use Chrome or Edge.");
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-IN'; // Default to English (Indian) for demo, ideally dynamic

  recognition.onresult = (event: any) => {
    if (event.results && event.results[0] && event.results[0][0]) {
       const text = event.results[0][0].transcript;
       onResult(text);
    }
  };

  recognition.onerror = (event: any) => {
    let message = "An error occurred with the microphone.";
    // Map specific error codes to friendly messages
    switch (event.error) {
      case 'no-speech':
        message = "No speech was detected. Please try again.";
        break;
      case 'audio-capture':
        message = "No microphone was found. Please ensure your microphone is plugged in and working.";
        break;
      case 'not-allowed':
        message = "Microphone access denied. Please allow microphone permissions in your browser address bar.";
        break;
      case 'network':
        message = "Network error occurred during speech recognition.";
        break;
      case 'aborted':
        // Often happens if stopped manually, can ignore or show 'Listening stopped'
        message = "Listening stopped.";
        break;
      default:
        message = `Speech recognition error: ${event.error}`;
    }
    
    // If it's just 'aborted' or 'no-speech', we might not want to treat it as a critical error in UI logic, 
    // but here we pass the message up.
    onError(message);
  };

  recognition.onend = () => {
    onEnd();
  };

  try {
    recognition.start();
  } catch (e) {
    onError("Could not start microphone. Please refresh and try again.");
  }
  
  return recognition;
};